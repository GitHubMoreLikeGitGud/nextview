"""A local LLM (Ollama, over HTTP with httpx) drives the NextView MCP server (spec section 9).

The driver starts ``nextview.mcp_server.server`` as an MCP stdio subprocess, converts the
server's tool schemas to Ollama's tool format and loops ``POST /api/chat`` (``stream=false``,
``temperature=0``). The model only chooses tool calls; every measurement, fit, uncertainty map,
stop check and candidate pose comes from the tools. Approvals asked by gated tools (MCP
elicitation) go to the terminal operator (``--approval ask``) or, for benchmarks, to a fixed
policy (``approve_all`` / ``deny_all``) that is recorded with the results.

The harness itself (not the model) opens the session, so every policy is run on the same
simulated camera, and reads the evaluator-only tools (``ground_truth_error``, ``session_log``)
after the episode; those tools are never offered to the model.

Every LLM turn and tool call is logged as one JSON line.

    python -m nextview.mcp_server.llm_driver --model qwen2.5:7b --camera-seed 1000 --budget 10
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from mcp import ClientSession, StdioServerParameters, types
from mcp.client.stdio import stdio_client

__all__ = ["EpisodeConfig", "ollama_tools", "simplify_schema", "system_prompt", "run_episode", "classify_result", "main"]

OLLAMA_URL = os.environ.get("OLLAMA_HOST_URL", "http://localhost:11434")
LLM_TOOLS = ("sim_capture", "detect_board", "assess_frame", "accept_view", "calibrate", "uncertainty_map",
             "residual_analysis", "propose_next_views", "drop_view", "export_calibration", "session_status")
HIDDEN_TOOLS = ("ground_truth_error", "session_log")  # evaluator only, never offered to the model
NUDGE = ("Continue by calling the next tool. When the calibration is finished, call export_calibration; "
         "after the export reply DONE.")


def system_prompt(budget: int) -> str:
    """The spec's prompt (section 9) plus the operating rules of the tool interface."""
    return ("You calibrate a camera. Each turn: capture, assess, accept or reject, calibrate, check uncertainty, "
            "choose the next view from propose_next_views. "
            f"Stop when P_exceed<0.10 or after {budget} accepted views.\n"
            "Rules: act only by calling tools; the tools do every measurement and calculation, so never invent "
            "numbers. Use the session_id you are given. sim_capture already detects and assesses the frame; "
            "accept_view only frames whose gate passed. Candidate lists are planned for the current views, so call "
            "propose_next_views again after every accepted view. To stop, call export_calibration (a human "
            "approves it), then reply DONE.")


def simplify_schema(schema: Any) -> Any:
    """Tool input schema for small models: ``anyOf [X, null]`` -> X, no titles."""
    if isinstance(schema, dict):
        out = {}
        for k, v in schema.items():
            if k == "title":
                continue
            out[k] = simplify_schema(v)
        any_of = out.get("anyOf")
        if isinstance(any_of, list):
            non_null = [s for s in any_of if not (isinstance(s, dict) and s.get("type") == "null")]
            if len(non_null) == 1:
                out.pop("anyOf")
                merged = dict(non_null[0])
                merged.update({k: v for k, v in out.items() if k not in merged})
                out = merged
        if out.get("default", 0) is None:
            out.pop("default")
        return out
    if isinstance(schema, list):
        return [simplify_schema(s) for s in schema]
    return schema


def ollama_tools(tools: list[types.Tool], allow: tuple[str, ...] = LLM_TOOLS) -> list[dict]:
    """MCP ``list_tools()`` result -> Ollama ``tools`` (only ``allow``, never the evaluator tools)."""
    out = []
    for t in tools:
        if t.name not in allow or t.name in HIDDEN_TOOLS:
            continue
        params = simplify_schema(t.inputSchema or {"type": "object", "properties": {}})
        out.append({"type": "function", "function": {"name": t.name, "description": t.description or "",
                                                     "parameters": params}})
    return out


def classify_result(res: types.CallToolResult) -> tuple[str, str | None]:
    """("ok" | "refused" | "needs_approval" | "bad_args" | "server_error", error code)."""
    sc = res.structuredContent or {}
    if res.isError:
        err = sc.get("error") if isinstance(sc, dict) else None
        if isinstance(err, dict):
            code = err.get("code")
            return ("server_error" if code == "INTERNAL" else "refused"), code
        return "bad_args", "VALIDATION"
    if isinstance(sc, dict) and sc.get("status") == "needs_approval":
        return "needs_approval", None
    return "ok", None


def _text(res: types.CallToolResult) -> str:
    return "\n".join(c.text for c in res.content if getattr(c, "type", None) == "text")


@dataclass
class EpisodeConfig:
    model: str = "qwen2.5:7b"
    preset: str = "inspection_gauge_cam"
    actuator: str = "robot"
    camera_seed: int = 1000
    seed: int = 0
    budget: int = 10
    max_calls: int = 40
    approval: str = "ask"  # ask | approve_all | deny_all
    stopcal: str = "config"
    ollama_url: str = OLLAMA_URL
    num_ctx: int = 16384
    think: bool | None = None
    temperature: float = 0.0
    max_history: int = 48  # messages kept after the system prompt and the task
    trim_chunk: int = 16
    max_nudges: int = 12
    max_consecutive_text: int = 3
    llm_timeout_s: float = 300.0
    log_path: str | None = None
    export_dir: str | None = None
    extra: dict = field(default_factory=dict)


class _Log:
    def __init__(self, path: str | None):
        self.f = None
        if path:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self.f = open(path, "w", encoding="utf-8")

    def write(self, rec: dict) -> None:
        if self.f:
            self.f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
            self.f.flush()

    def close(self) -> None:
        if self.f:
            self.f.close()


def _elicitation_callback(policy: str, record: list):
    async def cb(context, params) -> types.ElicitResult:
        msg = getattr(params, "message", "")
        if policy == "approve_all":
            ans = {"approve": True, "reason": "benchmark policy approve_all"}
        elif policy == "deny_all":
            ans = {"approve": False, "reason": "benchmark policy deny_all"}
        else:
            import anyio

            print(f"\n[APPROVAL] {msg}\nApprove? [y/n] ", end="", file=sys.stderr, flush=True)
            line = (await anyio.to_thread.run_sync(sys.stdin.readline)).strip().lower()
            ans = {"approve": line.startswith("y"), "reason": f"operator answered {line or 'n'!r}"}
        record.append({"message": msg, "answer": ans, "policy": policy})
        return types.ElicitResult(action="accept", content=ans)

    return cb


def _trim(messages: list[dict], head: int, cfg: EpisodeConfig) -> list[dict]:
    """Keep the system prompt and the task, and the most recent turns (dropped in chunks so the
    prompt prefix, and Ollama's cache of it, changes rarely). Never starts on a tool message."""
    rest = messages[head:]
    if len(rest) <= cfg.max_history:
        return messages
    cut = len(rest) - cfg.max_history + cfg.trim_chunk
    while cut < len(rest) and rest[cut].get("role") == "tool":
        cut += 1
    return messages[:head] + rest[cut:]


async def _chat(client: httpx.AsyncClient, cfg: EpisodeConfig, messages: list[dict], tools: list[dict]) -> dict:
    body: dict[str, Any] = {"model": cfg.model, "messages": messages, "tools": tools, "stream": False,
                            "options": {"temperature": cfg.temperature, "num_ctx": cfg.num_ctx, "seed": 0}}
    if cfg.think is not None:
        body["think"] = bool(cfg.think)
    last = None
    for attempt in range(3):
        try:
            r = await client.post(f"{cfg.ollama_url}/api/chat", json=body, timeout=cfg.llm_timeout_s)
            r.raise_for_status()
            return r.json()
        except (httpx.HTTPError, ValueError) as e:
            last = e
            await asyncio.sleep(2.0 * (attempt + 1))
    raise RuntimeError(f"Ollama /api/chat failed: {last}")


def _args_of(call: dict) -> tuple[dict | None, str | None]:
    fn = call.get("function") or {}
    a = fn.get("arguments", {})
    if isinstance(a, str):
        try:
            a = json.loads(a) if a.strip() else {}
        except json.JSONDecodeError as e:
            return None, f"arguments are not valid JSON ({e})"
    if not isinstance(a, dict):
        return None, f"arguments must be an object, got {type(a).__name__}"
    return a, None


_DONE = re.compile(r"\bDONE\b")


async def run_episode(cfg: EpisodeConfig) -> dict:
    """One LLM-driven calibration session. Returns the per-episode summary."""
    log = _Log(cfg.log_path)
    approvals: list = []
    args = ["-m", "nextview.mcp_server.server", "--stopcal", cfg.stopcal]
    if cfg.export_dir:
        args += ["--export-dir", cfg.export_dir]
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", PYTHONIOENCODING="utf-8")
    params = StdioServerParameters(command=sys.executable, args=args, env=env)
    t_start = time.perf_counter()
    calls: list[dict] = []
    llm_turns: list[dict] = []
    end_reason = None
    nudges = 0
    try:
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write, elicitation_callback=_elicitation_callback(cfg.approval, approvals)) as mcp:
                await mcp.initialize()
                listed = (await mcp.list_tools()).tools
                tools = ollama_tools(listed)
                allowed = {t["function"]["name"] for t in tools}
                res = await mcp.call_tool("sim_new_session", {"preset": cfg.preset, "actuator": cfg.actuator,
                                                              "seed": cfg.seed, "budget": cfg.budget,
                                                              "camera_seed": cfg.camera_seed})
                if res.isError:
                    raise RuntimeError(f"sim_new_session failed: {_text(res)}")
                sess = res.structuredContent
                sid = sess["session_id"]
                task = (f"Session {sid} is ready: {sess['preset']['label']} ({sess['preset']['family']} lens), "
                        f"{sess['actuator']} actuator, budget {cfg.budget} accepted views, target U95 tau "
                        f"{sess['tau_px']} px. Stop rule: {sess['stop_rule']}. Calibrate the camera now.")
                messages = [{"role": "system", "content": system_prompt(cfg.budget)}, {"role": "user", "content": task}]
                log.write({"kind": "start", "config": {k: v for k, v in cfg.__dict__.items() if k != "extra"},
                           "session_id": sid, "tools": sorted(allowed), "system": messages[0]["content"], "task": task})
                consecutive_text = 0
                async with httpx.AsyncClient() as http:
                    while end_reason is None:
                        if len(calls) >= cfg.max_calls:
                            end_reason = "call_cap"
                            break
                        messages = _trim(messages, 2, cfg)
                        t = time.perf_counter()
                        try:
                            resp = await _chat(http, cfg, messages, tools)
                        except RuntimeError as e:
                            end_reason = "llm_error"
                            log.write({"kind": "llm_error", "error": str(e)})
                            break
                        ms = 1000 * (time.perf_counter() - t)
                        msg = resp.get("message") or {}
                        tcs = msg.get("tool_calls") or []
                        turn = {"kind": "llm", "turn": len(llm_turns), "ms": round(ms, 1),
                                "prompt_tokens": resp.get("prompt_eval_count"), "eval_tokens": resp.get("eval_count"),
                                "content": (msg.get("content") or "")[:2000], "n_tool_calls": len(tcs),
                                "thinking_chars": len(msg.get("thinking") or "")}
                        llm_turns.append(turn)
                        log.write(turn)
                        keep = {"role": "assistant", "content": msg.get("content") or ""}
                        if tcs:
                            keep["tool_calls"] = tcs
                        messages.append(keep)
                        if not tcs:
                            consecutive_text += 1
                            if _DONE.search(msg.get("content") or ""):
                                end_reason = "done"
                            elif consecutive_text >= cfg.max_consecutive_text or nudges >= cfg.max_nudges:
                                end_reason = "stalled"
                            else:
                                nudges += 1
                                messages.append({"role": "user", "content": NUDGE})
                                log.write({"kind": "nudge", "n": nudges})
                            continue
                        consecutive_text = 0
                        for tc in tcs:
                            if len(calls) >= cfg.max_calls:
                                end_reason = "call_cap"
                                break
                            name = (tc.get("function") or {}).get("name")
                            a, perr = _args_of(tc)
                            rec = {"kind": "tool", "i": len(calls), "turn": turn["turn"], "tool": name, "args": a}
                            t = time.perf_counter()
                            if name not in allowed:
                                cat, code = "unknown_tool", None
                                text = f"error: unknown tool {name!r}; available tools: {', '.join(sorted(allowed))}"
                                sc = None
                            elif perr is not None:
                                cat, code, text, sc = "bad_args", "JSON", f"error: {perr}", None
                            else:
                                res = await mcp.call_tool(name, a)
                                cat, code = classify_result(res)
                                text, sc = _text(res), res.structuredContent
                            rec.update({"category": cat, "code": code, "ms": round(1000 * (time.perf_counter() - t), 1),
                                        "result": text[:1500]})
                            calls.append(rec)
                            log.write(rec)
                            tool_msg = {"role": "tool", "content": text, "tool_name": name or ""}
                            if tc.get("id"):
                                tool_msg["tool_call_id"] = tc["id"]
                            messages.append(tool_msg)
                            if isinstance(sc, dict) and (sc.get("exported") is True or sc.get("status") == "discarded"):
                                end_reason = "exported" if sc.get("exported") else "discarded"
                                break
                gt = await mcp.call_tool("ground_truth_error", {"session_id": sid})
                lg = await mcp.call_tool("session_log", {"session_id": sid})
                truth = gt.structuredContent or {}
                slog = lg.structuredContent or {}
    finally:
        log.close()
    summary = summarise(calls, llm_turns, slog, truth, approvals)
    summary.update({"model": cfg.model, "camera_seed": cfg.camera_seed, "seed": cfg.seed, "preset": cfg.preset,
                    "actuator": cfg.actuator, "budget": cfg.budget, "stopcal": cfg.stopcal, "approval_policy": cfg.approval,
                    "max_calls": cfg.max_calls, "end_reason": end_reason, "nudges": nudges, "session_id": sid,
                    "wall_s": round(time.perf_counter() - t_start, 1), "think": cfg.think})
    if cfg.log_path:
        with open(cfg.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps({"kind": "summary", **summary}, ensure_ascii=False, default=str) + "\n")
    return summary


def summarise(calls: list[dict], turns: list[dict], slog: dict, truth: dict, approvals: list) -> dict:
    """Tool-call validity, steps, agreement with the planner's rank 1, and the final errors."""
    n = len(calls)
    cats: dict[str, int] = {}
    codes: dict[str, int] = {}
    for c in calls:
        cats[c["category"]] = cats.get(c["category"], 0) + 1
        if c.get("code"):
            codes[c["code"]] = codes.get(c["code"], 0) + 1
    caps = slog.get("captures", [])
    nbv = [c for c in caps if c.get("source") == "nbv"]
    rank1 = [c for c in nbv if c.get("rank") == 1]
    accepted = slog.get("accepts", [])
    calls_at_40 = calls[:40]
    t = (truth or {}).get("truth") or {}
    by_tool: dict[str, int] = {}
    for c in calls:
        by_tool[c["tool"] or "?"] = by_tool.get(c["tool"] or "?", 0) + 1
    gate_failed_accepts = sum(1 for c in calls if c["tool"] == "accept_view" and c.get("code") == "GATE_FAILED")
    return {
        "tool_calls": n,
        "llm_turns": len(turns),
        "valid_calls": cats.get("ok", 0),
        "validity": round(cats.get("ok", 0) / n, 4) if n else None,
        "schema_valid": round((n - cats.get("unknown_tool", 0) - cats.get("bad_args", 0)) / n, 4) if n else None,
        "categories": cats,
        "refusal_codes": codes,
        "calls_by_tool": by_tool,
        "captures": len(caps),
        "nbv_captures": len(nbv),
        "agreement_rank1": round(len(rank1) / len(nbv), 4) if nbv else None,
        "rank_choices": {k: sum(1 for c in caps if c.get("chosen") == k) for k in sorted({c.get("chosen") for c in caps if c.get("chosen")})},
        "accepted_views": len(accepted),
        "final_views": slog.get("views"),
        "views_by_call_40": sum(1 for c in calls_at_40 if c["tool"] == "accept_view" and c["category"] == "ok"),
        "gate_failed_frames": sum(1 for c in caps if c.get("gate")),
        "accept_attempts_on_failed_frames": gate_failed_accepts,
        "exported": bool(slog.get("exported")),
        "export_warnings": None if not slog.get("exported") else slog["exported"].get("warnings"),
        "approvals": [{k: a.get(k) for k in ("kind", "decision")} for a in slog.get("approvals", [])],
        "model_final": (slog.get("model") or {}).get("name"),
        "final_U95_px": truth.get("U95_px"),
        "final_p_exceed": truth.get("p_exceed"),
        "final_true_p95_px": t.get("field_p95_px"),
        "fx_rel_err_pct": t.get("fx_rel_err_pct"),
        "mm_at_1m_edge": t.get("mm_at_1m_edge"),
        "true_p95_by_views": {a["views"]: (a.get("truth") or {}).get("field_p95_px") for a in accepted},
        "U95_by_views": {a["views"]: a.get("U95") for a in accepted},
        "llm_ms_total": round(sum(x["ms"] for x in turns), 1),
        "llm_ms_median": sorted(x["ms"] for x in turns)[len(turns) // 2] if turns else None,
        "tool_ms_total": round(sum(c["ms"] for c in calls), 1),
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m nextview.mcp_server.llm_driver", description=__doc__.splitlines()[0])
    ap.add_argument("--model", default="qwen2.5:7b")
    ap.add_argument("--preset", default="inspection_gauge_cam")
    ap.add_argument("--actuator", default="robot", choices=("robot", "human"))
    ap.add_argument("--camera-seed", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--budget", type=int, default=10)
    ap.add_argument("--max-calls", type=int, default=40)
    ap.add_argument("--approval", default="ask", choices=("ask", "approve_all", "deny_all"))
    ap.add_argument("--stopcal", default="config", help="config | identity | PATH (see the server)")
    ap.add_argument("--think", default=None, choices=("true", "false"), help="Ollama 'think' flag for reasoning models")
    ap.add_argument("--num-ctx", type=int, default=16384)
    ap.add_argument("--log", default=None, help="JSONL log path (default results/llm_row/run_<camera_seed>.jsonl)")
    ap.add_argument("--export-dir", default=None)
    ap.add_argument("--ollama-url", default=OLLAMA_URL)
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg = EpisodeConfig(model=a.model, preset=a.preset, actuator=a.actuator, camera_seed=a.camera_seed, seed=a.seed,
                        budget=a.budget, max_calls=a.max_calls, approval=a.approval, stopcal=a.stopcal,
                        think=None if a.think is None else a.think == "true", num_ctx=a.num_ctx,
                        log_path=a.log or f"results/llm_row/run_{a.camera_seed}.jsonl", export_dir=a.export_dir,
                        ollama_url=a.ollama_url)
    s = asyncio.run(run_episode(cfg))
    print(json.dumps({k: v for k, v in s.items() if k not in ("true_p95_by_views", "U95_by_views")}, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
